/** Original synthesized feedback. No third-party recordings or remote audio. */
export class FlightAudio {
  private context:AudioContext|null=null;
  enabled=false;
  unlock():void{try{this.context??=new AudioContext();void this.context.resume().catch(()=>{});}catch{this.enabled=false;}}
  tone(frequency:number,duration=.12,type:OscillatorType='sine',volume=.05):void{
    if(!this.enabled||!this.context||this.context.state!=='running')return;
    try{const c=this.context,o=c.createOscillator(),g=c.createGain();o.type=type;o.frequency.setValueAtTime(frequency,c.currentTime);o.frequency.exponentialRampToValueAtTime(frequency*.55,c.currentTime+duration);g.gain.setValueAtTime(volume,c.currentTime);g.gain.exponentialRampToValueAtTime(.0001,c.currentTime+duration);o.connect(g);g.connect(c.destination);o.start();o.stop(c.currentTime+duration);o.onended=()=>{o.disconnect();g.disconnect();};}catch{/* Sound failure never blocks play. */}
  }
  stop():void{if(this.context?.state==='running')void this.context.suspend().catch(()=>{});}
}
